﻿using UnityEngine;
using System.Collections;

public class ControllingCameraAspectScript : MonoBehaviour {
	
	// Use this for initialization
	void Start() {
		float aspect = (float)Screen.width / (float)Screen.height;
		
		if (aspect < 1.5f)
			Camera.main.orthographicSize = 3.6f;
		else
			Camera.main.orthographicSize = 3.2f;

	}
}